module.exports ={
    secret:"Kwanticha20-secret-key"
}