const authJwt = require("../middleware/authJwt")
const verifySignUp = require("../middleware/verifySignUp");

module.exports = {
    authJwt,
    verifySignUp
}