import logo from './logo.svg';
import Workout from './pages/Workout';
import './App.css';

function App() {
  return (
    <div className="App">
      <h1> Workout Tracker</h1>
      <Workout/>
    </div>
  );
}

export default App;
